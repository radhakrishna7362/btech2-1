interface Treasure{
    id:Number,
    name:String,
    location:String
}
export const treasure: Treasure = {
    id: 1,
    name: 'Windstorm Gold Staff',
    location: 'Tree behind home',
  };