import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'weather-details',
  templateUrl: './weatherDetails.component.html',
  styleUrls: ['./weatherDetails.component.scss']
})

export class WeatherDetails implements OnInit {
  @Input() weatherData: data[];
  public city:string;
  public result:data;
  public var1:data;
  ngOnInit() {

  }
  fuc1(){
    if(this.city !== "")
    {
      for(let i=0; i<this.weatherData.length;i++){
        if(this.weatherData[i].name.toLowerCase() === this.city.toLowerCase()){
          this.result=this.weatherData[i];
        }
      }
    }
    
    else if(this.city == "")
    {
      this.result=this.var1;
    }
    
  }
  
}

interface data {
  name: string;
  temperature: string;
  wind: string;
  humidity: string;
}