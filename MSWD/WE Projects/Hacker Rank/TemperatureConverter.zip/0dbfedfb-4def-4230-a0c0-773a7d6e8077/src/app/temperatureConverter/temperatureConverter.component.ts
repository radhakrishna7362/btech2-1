import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'temperature-converter',
  templateUrl: './temperatureConverter.component.html',
  styleUrls: ['./temperatureConverter.component.scss']
})

export class TemperatureConverter implements OnInit {
  public cel :number;
  public far :number;
  ngOnInit() {
    // C = (F − 32) * 5/9
    // F = C*9/5 + 32
  }
   func1(){
     this.far= this.cel*(1.8)+32;
     this.far= parseFloat(this.far.toFixed(1));
   }
   func2(){
     this.cel= ((this.far-32)*5)/9;
     this.cel=parseFloat(this.cel.toFixed(1));
   }

}